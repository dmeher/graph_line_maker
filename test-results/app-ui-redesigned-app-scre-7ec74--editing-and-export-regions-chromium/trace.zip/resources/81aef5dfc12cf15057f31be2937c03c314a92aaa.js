(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/lib/canvas/color.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "colorDistance",
    ()=>colorDistance,
    "contrastColor",
    ()=>contrastColor,
    "hexToRgb",
    ()=>hexToRgb,
    "nearestPaletteColor",
    ()=>nearestPaletteColor,
    "rgbToHex",
    ()=>rgbToHex
]);
function hexToRgb(hex) {
    const clean = hex.replace("#", "");
    return {
        r: Number.parseInt(clean.slice(0, 2), 16),
        g: Number.parseInt(clean.slice(2, 4), 16),
        b: Number.parseInt(clean.slice(4, 6), 16)
    };
}
function rgbToHex(rgb) {
    const value = [
        rgb.r,
        rgb.g,
        rgb.b
    ].map((channel)=>Math.max(0, Math.min(255, Math.round(channel))).toString(16).padStart(2, "0")).join("");
    return `#${value}`;
}
function colorDistance(left, right) {
    const r = left.r - right.r;
    const g = left.g - right.g;
    const b = left.b - right.b;
    return r * r + g * g + b * b;
}
function nearestPaletteColor(color, palette) {
    if (!palette.length) return color;
    let nearest = hexToRgb(palette[0].hex);
    let distance = Number.POSITIVE_INFINITY;
    for (const paletteColor of palette){
        const candidate = hexToRgb(paletteColor.hex);
        const nextDistance = colorDistance(color, candidate);
        if (nextDistance < distance) {
            nearest = candidate;
            distance = nextDistance;
        }
    }
    return nearest;
}
function contrastColor(hex) {
    const { r, g, b } = hexToRgb(hex);
    const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
    return luminance > 0.62 ? "#0f172a" : "#ffffff";
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/canvas/grid-numbering.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createGridNumberLabels",
    ()=>createGridNumberLabels
]);
function createGridNumberLabels(graphWidth, graphHeight, cellWidth, cellHeight) {
    const safeGraphWidth = Math.max(1, Math.round(graphWidth || 1));
    const safeGraphHeight = Math.max(1, Math.round(graphHeight || 1));
    const safeCellWidth = Math.max(1, cellWidth || 1);
    const safeCellHeight = Math.max(1, cellHeight || 1);
    const top = Array.from({
        length: safeGraphWidth
    }, (_, index)=>({
            value: index + 1,
            x: Math.round((index + 0.5) * safeCellWidth),
            y: Math.round(safeCellHeight * 0.28)
        }));
    const bottom = top.map((label)=>({
            ...label,
            y: Math.round(safeGraphHeight * safeCellHeight - safeCellHeight * 0.18)
        }));
    const left = Array.from({
        length: safeGraphHeight
    }, (_, index)=>({
            value: index + 1,
            x: Math.round(safeCellWidth * 0.18),
            y: Math.round((index + 0.55) * safeCellHeight)
        }));
    const right = left.map((label)=>({
            ...label,
            x: Math.round(safeGraphWidth * safeCellWidth - safeCellWidth * 0.18)
        }));
    return {
        top,
        bottom,
        left,
        right
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/canvas/ink-mask.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "maskFromImageData",
    ()=>maskFromImageData
]);
const MIN_ALPHA_FOR_INK = 16;
const BACKGROUND_CONTRAST_GAP = 72;
const COLOR_DISTANCE_THRESHOLD = 58;
const MIN_COLORED_INK_CHANNEL_SPREAD = 18;
const MAX_INK_LUMA_THRESHOLD = 190;
const MIN_INK_LUMA_THRESHOLD = 48;
function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
}
function lumaForRgb(red, green, blue) {
    return 0.299 * red + 0.587 * green + 0.114 * blue;
}
function percentileFromHistogram(histogram, total, percentile) {
    const target = Math.max(1, Math.round(total * percentile));
    let seen = 0;
    for(let value = 0; value < histogram.length; value += 1){
        seen += histogram[value];
        if (seen >= target) return value;
    }
    return histogram.length - 1;
}
function analyzeImageData(imageData) {
    const histogram = new Uint32Array(256);
    const data = imageData.data;
    let total = 0;
    for(let index = 0; index < data.length; index += 4){
        if (data[index + 3] < MIN_ALPHA_FOR_INK) continue;
        const luma = Math.round(lumaForRgb(data[index], data[index + 1], data[index + 2]));
        histogram[clamp(luma, 0, 255)] += 1;
        total += 1;
    }
    if (!total) {
        return {
            brightLuma: 255,
            inkThreshold: 238,
            background: {
                red: 255,
                green: 255,
                blue: 255
            }
        };
    }
    const brightLuma = percentileFromHistogram(histogram, total, 0.92);
    const inkThreshold = clamp(brightLuma - BACKGROUND_CONTRAST_GAP, MIN_INK_LUMA_THRESHOLD, MAX_INK_LUMA_THRESHOLD);
    let redTotal = 0;
    let greenTotal = 0;
    let blueTotal = 0;
    let backgroundCount = 0;
    for(let index = 0; index < data.length; index += 4){
        if (data[index + 3] < MIN_ALPHA_FOR_INK) continue;
        const luma = lumaForRgb(data[index], data[index + 1], data[index + 2]);
        if (luma < brightLuma) continue;
        redTotal += data[index];
        greenTotal += data[index + 1];
        blueTotal += data[index + 2];
        backgroundCount += 1;
    }
    return {
        brightLuma,
        inkThreshold,
        background: {
            red: backgroundCount ? redTotal / backgroundCount : 255,
            green: backgroundCount ? greenTotal / backgroundCount : 255,
            blue: backgroundCount ? blueTotal / backgroundCount : 255
        }
    };
}
function colorDistance(red, green, blue, background) {
    const redDistance = red - background.red;
    const greenDistance = green - background.green;
    const blueDistance = blue - background.blue;
    return Math.sqrt(redDistance * redDistance + greenDistance * greenDistance + blueDistance * blueDistance);
}
function minimumInkComponentPixels(width, height) {
    return Math.max(3, Math.min(64, Math.round(Math.sqrt(width * height) * 0.016)));
}
function removeSmallInkComponents(mask, width, height, count) {
    const minPixels = minimumInkComponentPixels(width, height);
    if (count < minPixels) return {
        mask,
        count
    };
    const visited = new Uint8Array(mask.length);
    const queue = new Int32Array(mask.length);
    let cleanCount = count;
    function enqueue(index, tail) {
        if (visited[index] || !mask[index]) return tail;
        visited[index] = 1;
        queue[tail] = index;
        return tail + 1;
    }
    for(let start = 0; start < mask.length; start += 1){
        if (visited[start] || !mask[start]) continue;
        let head = 0;
        let tail = 0;
        tail = enqueue(start, tail);
        while(head < tail){
            const index = queue[head];
            head += 1;
            const x = index % width;
            const y = Math.floor(index / width);
            for(let yy = Math.max(0, y - 1); yy <= Math.min(height - 1, y + 1); yy += 1){
                for(let xx = Math.max(0, x - 1); xx <= Math.min(width - 1, x + 1); xx += 1){
                    const next = yy * width + xx;
                    tail = enqueue(next, tail);
                }
            }
        }
        if (tail >= minPixels) continue;
        cleanCount -= tail;
        for(let index = 0; index < tail; index += 1){
            mask[queue[index]] = 0;
        }
    }
    return {
        mask,
        count: cleanCount
    };
}
function maskFromImageData(imageData) {
    const mask = new Uint8Array(imageData.width * imageData.height);
    const data = imageData.data;
    const analysis = analyzeImageData(imageData);
    let count = 0;
    for(let index = 0, pixel = 0; index < data.length; index += 4, pixel += 1){
        const alpha = data[index + 3];
        if (alpha < MIN_ALPHA_FOR_INK) continue;
        const red = data[index];
        const green = data[index + 1];
        const blue = data[index + 2];
        const luma = lumaForRgb(red, green, blue);
        const channelSpread = Math.max(red, green, blue) - Math.min(red, green, blue);
        const isDarkInk = luma <= analysis.inkThreshold;
        const isColoredInk = channelSpread >= MIN_COLORED_INK_CHANNEL_SPREAD && luma <= analysis.brightLuma - 12 && colorDistance(red, green, blue, analysis.background) >= COLOR_DISTANCE_THRESHOLD;
        if (!isDarkInk && !isColoredInk) continue;
        mask[pixel] = 1;
        count += 1;
    }
    const cleaned = removeSmallInkComponents(mask, imageData.width, imageData.height, count);
    return {
        mask: cleaned.mask,
        count: cleaned.count,
        threshold: analysis.inkThreshold
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/constants.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ALLOWED_IMAGE_EXTENSIONS",
    ()=>ALLOWED_IMAGE_EXTENSIONS,
    "ALLOWED_IMAGE_LABEL",
    ()=>ALLOWED_IMAGE_LABEL,
    "ALLOWED_IMAGE_TYPES",
    ()=>ALLOWED_IMAGE_TYPES,
    "BOOTSTRAP_ADMIN_EMAIL",
    ()=>BOOTSTRAP_ADMIN_EMAIL,
    "GRAPH_PIXEL_SCHEMA",
    ()=>GRAPH_PIXEL_SCHEMA,
    "GRAPH_PIXEL_SESSION_COOKIE",
    ()=>GRAPH_PIXEL_SESSION_COOKIE,
    "IMAGE_ACCEPT",
    ()=>IMAGE_ACCEPT,
    "MAX_UPLOAD_BYTES",
    ()=>MAX_UPLOAD_BYTES,
    "ORIGINAL_IMAGES_BUCKET",
    ()=>ORIGINAL_IMAGES_BUCKET,
    "PROCESSED_IMAGES_BUCKET",
    ()=>PROCESSED_IMAGES_BUCKET,
    "getAllowedImageContentType",
    ()=>getAllowedImageContentType,
    "getImageExtension",
    ()=>getImageExtension,
    "isAllowedImageFile",
    ()=>isAllowedImageFile,
    "isPdfFile",
    ()=>isPdfFile
]);
const GRAPH_PIXEL_SCHEMA = "image_to_graph";
const GRAPH_PIXEL_SESSION_COOKIE = "graph_pixel_session";
const ORIGINAL_IMAGES_BUCKET = "graph-pixel-original-images";
const PROCESSED_IMAGES_BUCKET = "graph-pixel-processed-images";
const BOOTSTRAP_ADMIN_EMAIL = "dmeher1996@gmail.com";
const MAX_UPLOAD_BYTES = 50 * 1024 * 1024;
const ALLOWED_IMAGE_TYPES = [
    "image/png",
    "image/jpeg",
    "image/webp",
    "image/svg+xml",
    "application/pdf",
    "application/x-pdf"
];
const ALLOWED_IMAGE_EXTENSIONS = new Set([
    "png",
    "jpg",
    "jpeg",
    "webp",
    "svg",
    "pdf"
]);
const ALLOWED_IMAGE_LABEL = "PNG, JPG, JPEG, WEBP, SVG, or PDF";
const IMAGE_ACCEPT = "image/png,image/jpeg,image/webp,image/svg+xml,application/pdf,.svg,.pdf";
function getImageExtension(fileName) {
    return fileName.split(".").pop()?.toLowerCase() || "";
}
function isPdfFile(input) {
    const type = input.type?.toLowerCase() || "";
    if (type === "application/pdf" || type === "application/x-pdf") return true;
    return getImageExtension(input.name || "") === "pdf";
}
function isAllowedImageFile(input) {
    const type = input.type?.toLowerCase() || "";
    if (ALLOWED_IMAGE_TYPES.includes(type)) return true;
    const extension = getImageExtension(input.name || "");
    const canTrustExtension = !type || type === "application/octet-stream" || type === "text/xml" || type === "application/xml";
    return canTrustExtension && ALLOWED_IMAGE_EXTENSIONS.has(extension);
}
function getAllowedImageContentType(input) {
    const type = input.type?.toLowerCase() || "";
    if (ALLOWED_IMAGE_TYPES.includes(type)) return type;
    switch(getImageExtension(input.name || "")){
        case "png":
            return "image/png";
        case "jpg":
        case "jpeg":
            return "image/jpeg";
        case "webp":
            return "image/webp";
        case "svg":
            return "image/svg+xml";
        case "pdf":
            return "application/pdf";
        default:
            return null;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/canvas/pdf.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isPdfSource",
    ()=>isPdfSource,
    "readPdfFirstPageSize",
    ()=>readPdfFirstPageSize,
    "renderPdfFirstPageToCanvas",
    ()=>renderPdfFirstPageToCanvas
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/constants.ts [app-client] (ecmascript)");
const __TURBOPACK__import$2e$meta__ = {
    get url () {
        return `file://${__turbopack_context__.P("src/lib/canvas/pdf.ts")}`;
    },
    get turbopackHot () {
        return __turbopack_context__.m.hot;
    }
};
;
const PDF_RENDER_MAX_DIMENSION = 4200;
const PDF_RENDER_MAX_PIXELS = 14_000_000;
let pdfWorkerConfigured = false;
async function getPdfJs() {
    const pdfjs = await __turbopack_context__.A("[project]/node_modules/pdfjs-dist/build/pdf.mjs [app-client] (ecmascript, async loader)");
    if (!pdfWorkerConfigured) {
        pdfjs.GlobalWorkerOptions.workerSrc = new __turbopack_context__.U(__turbopack_context__.r("[project]/node_modules/pdfjs-dist/build/pdf.worker.mjs (static in ecmascript, tag client)")).toString();
        pdfWorkerConfigured = true;
    }
    return pdfjs;
}
async function sourceToArrayBuffer(source) {
    if (typeof source !== "string") return source.arrayBuffer();
    const response = await fetch(source);
    if (!response.ok) throw new Error("Unable to load PDF source.");
    return response.arrayBuffer();
}
function pdfRenderScale(width, height) {
    const dimensionScale = Math.min(1, PDF_RENDER_MAX_DIMENSION / width, PDF_RENDER_MAX_DIMENSION / height);
    const pixelScale = Math.min(1, Math.sqrt(PDF_RENDER_MAX_PIXELS / Math.max(1, width * height)));
    return Math.max(0.1, Math.min(dimensionScale, pixelScale));
}
function isPdfSource(source, fileName) {
    if (typeof source !== "string") return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPdfFile"])(source);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPdfFile"])({
        name: fileName || source.split("?")[0]
    });
}
async function readPdfFirstPageSize(source) {
    const pdfjs = await getPdfJs();
    const data = new Uint8Array(await sourceToArrayBuffer(source));
    const loadingTask = pdfjs.getDocument({
        data
    });
    const pdf = await loadingTask.promise;
    try {
        const page = await pdf.getPage(1);
        const viewport = page.getViewport({
            scale: 1
        });
        return {
            width: Math.max(1, Math.round(viewport.width)),
            height: Math.max(1, Math.round(viewport.height)),
            pageCount: pdf.numPages
        };
    } finally{
        await pdf.destroy();
    }
}
async function renderPdfFirstPageToCanvas(source) {
    const pdfjs = await getPdfJs();
    const data = new Uint8Array(await sourceToArrayBuffer(source));
    const loadingTask = pdfjs.getDocument({
        data
    });
    const pdf = await loadingTask.promise;
    try {
        const page = await pdf.getPage(1);
        const baseViewport = page.getViewport({
            scale: 1
        });
        const viewport = page.getViewport({
            scale: pdfRenderScale(baseViewport.width, baseViewport.height)
        });
        const canvas = document.createElement("canvas");
        canvas.width = Math.max(1, Math.ceil(viewport.width));
        canvas.height = Math.max(1, Math.ceil(viewport.height));
        const context = canvas.getContext("2d", {
            alpha: false
        });
        if (!context) throw new Error("Canvas is not available.");
        context.fillStyle = "#ffffff";
        context.fillRect(0, 0, canvas.width, canvas.height);
        await page.render({
            canvas,
            viewport,
            background: "white"
        }).promise;
        return {
            canvas,
            width: Math.max(1, Math.round(baseViewport.width)),
            height: Math.max(1, Math.round(baseViewport.height)),
            pageCount: pdf.numPages
        };
    } finally{
        await pdf.destroy();
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/canvas/thinning.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "boundaryMask",
    ()=>boundaryMask,
    "createThinArtworkMasks",
    ()=>createThinArtworkMasks,
    "dilateMask",
    ()=>dilateMask,
    "expandMaskForLineSize",
    ()=>expandMaskForLineSize,
    "thinMask",
    ()=>thinMask
]);
const FILLED_ASPECT_RATIO_LIMIT = 3;
const DEFAULT_SOURCE_FILL_THRESHOLD = 0.58;
const MIN_SOURCE_FILL_THRESHOLD = 0.05;
const MAX_SOURCE_FILL_THRESHOLD = 1;
const DEFAULT_SOURCE_FILL_MIN_STROKE_PIXELS = 7;
const MIN_SOURCE_FILL_MIN_STROKE_PIXELS = 2;
const MAX_SOURCE_FILL_MIN_STROKE_PIXELS = 48;
const DEFAULT_STROKE_GAP_CLOSE_PIXELS = 0;
const MIN_STROKE_GAP_CLOSE_PIXELS = 0;
const MAX_STROKE_GAP_CLOSE_PIXELS = 2;
const MIN_COMPONENT_PIXELS = 3;
const MIN_SOLID_FILL_MINOR_AXIS = 5;
const MIN_SIGNIFICANT_HOLE_PIXELS = 8;
const MIN_SIGNIFICANT_HOLE_RATIO = 0.025;
const MIN_SCANLINE_ARTIFACT_PIXELS = 24;
const SCANLINE_ARTIFACT_RATIO = 0.12;
const SCANLINE_ISOLATED_RATIO = 0.72;
const SCANLINE_COMPONENT_ASPECT_RATIO = 12;
const SCANLINE_COMPONENT_LONG_SIDE_RATIO = 0.18;
const SCANLINE_COMPONENT_MAX_SHORT_SIDE_RATIO = 0.012;
function clampNumber(value, min, max, fallback) {
    const numeric = Number(value);
    if (!Number.isFinite(numeric)) return fallback;
    return Math.max(min, Math.min(max, numeric));
}
function normalizeFillThreshold(value) {
    return clampNumber(value, MIN_SOURCE_FILL_THRESHOLD, MAX_SOURCE_FILL_THRESHOLD, DEFAULT_SOURCE_FILL_THRESHOLD);
}
function normalizeFillMinStrokePixels(value) {
    return Math.round(clampNumber(value, MIN_SOURCE_FILL_MIN_STROKE_PIXELS, MAX_SOURCE_FILL_MIN_STROKE_PIXELS, DEFAULT_SOURCE_FILL_MIN_STROKE_PIXELS));
}
function normalizeGapClosePixels(value) {
    return Math.round(clampNumber(value, MIN_STROKE_GAP_CLOSE_PIXELS, MAX_STROKE_GAP_CLOSE_PIXELS, DEFAULT_STROKE_GAP_CLOSE_PIXELS));
}
function copyMask(mask) {
    const output = new Uint8Array(mask.length);
    output.set(mask);
    return output;
}
function boundaryMask(mask, width, height) {
    const boundary = new Uint8Array(mask.length);
    for(let y = 0; y < height; y += 1){
        for(let x = 0; x < width; x += 1){
            const index = y * width + x;
            if (!mask[index]) continue;
            if (x === 0 || y === 0 || x === width - 1 || y === height - 1 || !mask[index - 1] || !mask[index + 1] || !mask[index - width] || !mask[index + width]) {
                boundary[index] = 1;
            }
        }
    }
    return boundary;
}
function dilateMask(mask, width, height, radius) {
    if (radius <= 0) return copyMask(mask);
    const output = new Uint8Array(mask.length);
    for(let y = 0; y < height; y += 1){
        for(let x = 0; x < width; x += 1){
            const index = y * width + x;
            if (!mask[index]) continue;
            for(let yy = Math.max(0, y - radius); yy <= Math.min(height - 1, y + radius); yy += 1){
                for(let xx = Math.max(0, x - radius); xx <= Math.min(width - 1, x + radius); xx += 1){
                    output[yy * width + xx] = 1;
                }
            }
        }
    }
    return output;
}
function erodeMask(mask, width, height, radius) {
    if (radius <= 0) return copyMask(mask);
    const output = new Uint8Array(mask.length);
    for(let y = 0; y < height; y += 1){
        for(let x = 0; x < width; x += 1){
            let keep = true;
            for(let yy = y - radius; yy <= y + radius && keep; yy += 1){
                for(let xx = x - radius; xx <= x + radius; xx += 1){
                    if (xx < 0 || yy < 0 || xx >= width || yy >= height || !mask[yy * width + xx]) {
                        keep = false;
                        break;
                    }
                }
            }
            if (keep) output[y * width + x] = 1;
        }
    }
    return output;
}
function closeMask(mask, width, height, radius) {
    if (radius <= 0) return copyMask(mask);
    return erodeMask(dilateMask(mask, width, height, radius), width, height, radius);
}
function hasPerpendicularSupport(mask, width, height, x, y, horizontal) {
    if (horizontal) {
        for(let yy = Math.max(0, y - 1); yy <= Math.min(height - 1, y + 1); yy += 1){
            if (yy === y) continue;
            for(let xx = Math.max(0, x - 1); xx <= Math.min(width - 1, x + 1); xx += 1){
                if (mask[yy * width + xx]) return true;
            }
        }
        return false;
    }
    for(let yy = Math.max(0, y - 1); yy <= Math.min(height - 1, y + 1); yy += 1){
        for(let xx = Math.max(0, x - 1); xx <= Math.min(width - 1, x + 1); xx += 1){
            if (xx === x) continue;
            if (mask[yy * width + xx]) return true;
        }
    }
    return false;
}
function removeScanlineArtifacts(mask, width, height) {
    const output = copyMask(mask);
    const minHorizontalPixels = Math.max(MIN_SCANLINE_ARTIFACT_PIXELS, Math.round(width * SCANLINE_ARTIFACT_RATIO));
    const minVerticalPixels = Math.max(MIN_SCANLINE_ARTIFACT_PIXELS, Math.round(height * SCANLINE_ARTIFACT_RATIO));
    for(let y = 0; y < height; y += 1){
        let rowCount = 0;
        let isolatedCount = 0;
        for(let x = 0; x < width; x += 1){
            const index = y * width + x;
            if (!mask[index]) continue;
            rowCount += 1;
            if (!hasPerpendicularSupport(mask, width, height, x, y, true)) isolatedCount += 1;
        }
        if (rowCount < minHorizontalPixels || isolatedCount / rowCount < SCANLINE_ISOLATED_RATIO) continue;
        for(let x = 0; x < width; x += 1){
            const index = y * width + x;
            if (mask[index] && !hasPerpendicularSupport(mask, width, height, x, y, true)) output[index] = 0;
        }
    }
    for(let x = 0; x < width; x += 1){
        let columnCount = 0;
        let isolatedCount = 0;
        for(let y = 0; y < height; y += 1){
            const index = y * width + x;
            if (!output[index]) continue;
            columnCount += 1;
            if (!hasPerpendicularSupport(output, width, height, x, y, false)) isolatedCount += 1;
        }
        if (columnCount < minVerticalPixels || isolatedCount / columnCount < SCANLINE_ISOLATED_RATIO) continue;
        for(let y = 0; y < height; y += 1){
            const index = y * width + x;
            if (output[index] && !hasPerpendicularSupport(output, width, height, x, y, false)) output[index] = 0;
        }
    }
    return output;
}
function neighborCount(mask, width, index) {
    return mask[index - width] + mask[index - width + 1] + mask[index + 1] + mask[index + width + 1] + mask[index + width] + mask[index + width - 1] + mask[index - 1] + mask[index - width - 1];
}
function transitionCount(mask, width, index) {
    const values = [
        mask[index - width],
        mask[index - width + 1],
        mask[index + 1],
        mask[index + width + 1],
        mask[index + width],
        mask[index + width - 1],
        mask[index - 1],
        mask[index - width - 1]
    ];
    let transitions = 0;
    for(let current = 0; current < values.length; current += 1){
        const next = (current + 1) % values.length;
        if (!values[current] && values[next]) transitions += 1;
    }
    return transitions;
}
function thinMask(mask, width, height) {
    const output = copyMask(mask);
    if (width < 3 || height < 3) return output;
    const remove = new Uint8Array(mask.length);
    let changed = true;
    while(changed){
        changed = false;
        remove.fill(0);
        for(let y = 1; y < height - 1; y += 1){
            for(let x = 1; x < width - 1; x += 1){
                const index = y * width + x;
                if (!output[index]) continue;
                const neighbors = neighborCount(output, width, index);
                if (neighbors < 2 || neighbors > 6 || transitionCount(output, width, index) !== 1) continue;
                if (output[index - width] && output[index + 1] && output[index + width]) continue;
                if (output[index + 1] && output[index + width] && output[index - 1]) continue;
                remove[index] = 1;
            }
        }
        for(let index = 0; index < remove.length; index += 1){
            if (!remove[index]) continue;
            output[index] = 0;
            changed = true;
        }
        remove.fill(0);
        for(let y = 1; y < height - 1; y += 1){
            for(let x = 1; x < width - 1; x += 1){
                const index = y * width + x;
                if (!output[index]) continue;
                const neighbors = neighborCount(output, width, index);
                if (neighbors < 2 || neighbors > 6 || transitionCount(output, width, index) !== 1) continue;
                if (output[index - width] && output[index + 1] && output[index - 1]) continue;
                if (output[index - width] && output[index + width] && output[index - 1]) continue;
                remove[index] = 1;
            }
        }
        for(let index = 0; index < remove.length; index += 1){
            if (!remove[index]) continue;
            output[index] = 0;
            changed = true;
        }
    }
    return output;
}
function expandMaskForLineSize(mask, width, height, lineSize) {
    const radius = Math.max(0, Math.floor(Math.max(0, lineSize) / 2));
    return radius > 0 ? dilateMask(mask, width, height, radius) : copyMask(mask);
}
function componentHoleCount(width, component, count, bounds) {
    const localWidth = bounds.width;
    const localHeight = bounds.height;
    const localSize = localWidth * localHeight;
    const local = new Uint8Array(localSize);
    const outside = new Uint8Array(localSize);
    const queue = new Int32Array(localSize);
    let head = 0;
    let tail = 0;
    for(let index = 0; index < count; index += 1){
        const pixel = component[index];
        const x = pixel % width;
        const y = Math.floor(pixel / width);
        local[(y - bounds.y) * localWidth + (x - bounds.x)] = 1;
    }
    function enqueue(localIndex) {
        if (local[localIndex] || outside[localIndex]) return;
        outside[localIndex] = 1;
        queue[tail] = localIndex;
        tail += 1;
    }
    for(let x = 0; x < localWidth; x += 1){
        enqueue(x);
        enqueue((localHeight - 1) * localWidth + x);
    }
    for(let y = 1; y < localHeight - 1; y += 1){
        enqueue(y * localWidth);
        enqueue(y * localWidth + localWidth - 1);
    }
    while(head < tail){
        const localIndex = queue[head];
        head += 1;
        const x = localIndex % localWidth;
        const y = Math.floor(localIndex / localWidth);
        if (x > 0) enqueue(localIndex - 1);
        if (x < localWidth - 1) enqueue(localIndex + 1);
        if (y > 0) enqueue(localIndex - localWidth);
        if (y < localHeight - 1) enqueue(localIndex + localWidth);
    }
    let holes = 0;
    for(let index = 0; index < local.length; index += 1){
        if (!local[index] && !outside[index]) holes += 1;
    }
    return holes;
}
function isSolidFillComponent(width, component, count, bounds, threshold) {
    if (count < MIN_COMPONENT_PIXELS) return false;
    const boundsArea = bounds.width * bounds.height;
    const coverage = count / Math.max(1, boundsArea);
    if (coverage < threshold) return false;
    if (Math.min(bounds.width, bounds.height) < MIN_SOLID_FILL_MINOR_AXIS) return false;
    const aspectRatio = Math.max(bounds.width, bounds.height) / Math.max(1, Math.min(bounds.width, bounds.height));
    if (aspectRatio >= FILLED_ASPECT_RATIO_LIMIT) return false;
    const holes = componentHoleCount(width, component, count, bounds);
    const significantHolePixels = Math.max(MIN_SIGNIFICANT_HOLE_PIXELS, Math.round(boundsArea * MIN_SIGNIFICANT_HOLE_RATIO));
    return holes < significantHolePixels;
}
function isScanlineComponent(width, height, bounds) {
    const longSide = Math.max(bounds.width, bounds.height);
    const shortSide = Math.min(bounds.width, bounds.height);
    const aspectRatio = longSide / Math.max(1, shortSide);
    const minLongSide = Math.max(MIN_SCANLINE_ARTIFACT_PIXELS, Math.round(Math.max(width, height) * SCANLINE_COMPONENT_LONG_SIDE_RATIO));
    const maxShortSide = Math.max(2, Math.round(Math.min(width, height) * SCANLINE_COMPONENT_MAX_SHORT_SIDE_RATIO));
    return aspectRatio >= SCANLINE_COMPONENT_ASPECT_RATIO && longSide >= minLongSide && shortSide <= maxShortSide;
}
function createLocalComponentMask(width, component, count, bounds) {
    const localWidth = bounds.width;
    const local = new Uint8Array(localWidth * bounds.height);
    for(let index = 0; index < count; index += 1){
        const pixel = component[index];
        const x = pixel % width;
        const y = Math.floor(pixel / width);
        local[(y - bounds.y) * localWidth + (x - bounds.x)] = 1;
    }
    return local;
}
function isLocalBoundary(local, width, height, x, y) {
    for(let yy = y - 1; yy <= y + 1; yy += 1){
        for(let xx = x - 1; xx <= x + 1; xx += 1){
            if (xx === x && yy === y) continue;
            if (xx < 0 || yy < 0 || xx >= width || yy >= height || !local[yy * width + xx]) return true;
        }
    }
    return false;
}
function distanceFromComponentBoundary(local, width, height, count) {
    const distance = new Uint16Array(local.length);
    const queue = new Int32Array(count);
    let head = 0;
    let tail = 0;
    for(let y = 0; y < height; y += 1){
        for(let x = 0; x < width; x += 1){
            const index = y * width + x;
            if (!local[index] || !isLocalBoundary(local, width, height, x, y)) continue;
            distance[index] = 1;
            queue[tail] = index;
            tail += 1;
        }
    }
    while(head < tail){
        const index = queue[head];
        head += 1;
        const x = index % width;
        const y = Math.floor(index / width);
        const nextDistance = distance[index] + 1;
        for(let yy = Math.max(0, y - 1); yy <= Math.min(height - 1, y + 1); yy += 1){
            for(let xx = Math.max(0, x - 1); xx <= Math.min(width - 1, x + 1); xx += 1){
                const nextIndex = yy * width + xx;
                if (!local[nextIndex] || distance[nextIndex]) continue;
                distance[nextIndex] = nextDistance;
                queue[tail] = nextIndex;
                tail += 1;
            }
        }
    }
    return distance;
}
function estimatedSourceWidth(distance) {
    return distance > 0 ? distance * 2 - 1 : 0;
}
function dilateLocalFill(fill, local, width, height, radius) {
    if (radius <= 0) return fill;
    const output = new Uint8Array(fill.length);
    for(let y = 0; y < height; y += 1){
        for(let x = 0; x < width; x += 1){
            const index = y * width + x;
            if (!fill[index]) continue;
            for(let yy = Math.max(0, y - radius); yy <= Math.min(height - 1, y + radius); yy += 1){
                for(let xx = Math.max(0, x - radius); xx <= Math.min(width - 1, x + radius); xx += 1){
                    const nextIndex = yy * width + xx;
                    if (local[nextIndex]) output[nextIndex] = 1;
                }
            }
        }
    }
    return output;
}
function fillMaskForWideStrokes(width, component, count, bounds, sourceFillThreshold, sourceFillMinStrokePixels) {
    const localWidth = bounds.width;
    const localHeight = bounds.height;
    const local = createLocalComponentMask(width, component, count, bounds);
    const distance = distanceFromComponentBoundary(local, localWidth, localHeight, count);
    const fill = new Uint8Array(local.length);
    const queue = new Int32Array(count);
    const growWidthThreshold = Math.max(1, Math.min(sourceFillMinStrokePixels, Math.round(sourceFillMinStrokePixels * sourceFillThreshold)));
    let head = 0;
    let tail = 0;
    for(let index = 0; index < local.length; index += 1){
        if (!local[index] || estimatedSourceWidth(distance[index]) < sourceFillMinStrokePixels) continue;
        fill[index] = 1;
        queue[tail] = index;
        tail += 1;
    }
    if (!tail) return null;
    while(head < tail){
        const index = queue[head];
        head += 1;
        const x = index % localWidth;
        const y = Math.floor(index / localWidth);
        for(let yy = Math.max(0, y - 1); yy <= Math.min(localHeight - 1, y + 1); yy += 1){
            for(let xx = Math.max(0, x - 1); xx <= Math.min(localWidth - 1, x + 1); xx += 1){
                const nextIndex = yy * localWidth + xx;
                if (fill[nextIndex] || !local[nextIndex] || estimatedSourceWidth(distance[nextIndex]) < growWidthThreshold) continue;
                fill[nextIndex] = 1;
                queue[tail] = nextIndex;
                tail += 1;
            }
        }
    }
    const restoreRadius = Math.max(0, Math.floor(growWidthThreshold / 2));
    return dilateLocalFill(fill, local, localWidth, localHeight, restoreRadius);
}
function paintComponent(width, component, count, bounds, fillLocalMask, fillMask, strokeMask) {
    for(let index = 0; index < count; index += 1){
        const pixel = component[index];
        if (!fillLocalMask) {
            strokeMask[pixel] = 1;
            continue;
        }
        const x = pixel % width;
        const y = Math.floor(pixel / width);
        const localIndex = (y - bounds.y) * bounds.width + (x - bounds.x);
        if (fillLocalMask[localIndex]) fillMask[pixel] = 1;
        else strokeMask[pixel] = 1;
    }
}
function enclosedRegionMask(barrierMask, width, height) {
    const outside = new Uint8Array(barrierMask.length);
    const enclosed = new Uint8Array(barrierMask.length);
    const queue = new Int32Array(barrierMask.length);
    let head = 0;
    let tail = 0;
    function enqueue(index) {
        if (outside[index] || barrierMask[index]) return;
        outside[index] = 1;
        queue[tail] = index;
        tail += 1;
    }
    for(let x = 0; x < width; x += 1){
        enqueue(x);
        enqueue((height - 1) * width + x);
    }
    for(let y = 1; y < height - 1; y += 1){
        enqueue(y * width);
        enqueue(y * width + width - 1);
    }
    while(head < tail){
        const index = queue[head];
        head += 1;
        const x = index % width;
        const y = Math.floor(index / width);
        if (x > 0) enqueue(index - 1);
        if (x < width - 1) enqueue(index + 1);
        if (y > 0) enqueue(index - width);
        if (y < height - 1) enqueue(index + width);
    }
    for(let index = 0; index < barrierMask.length; index += 1){
        if (!barrierMask[index] && !outside[index]) enclosed[index] = 1;
    }
    return enclosed;
}
function createThinArtworkMasks(inkMask, width, height, options = {}) {
    const sourceFillThreshold = normalizeFillThreshold(options.sourceFillThreshold);
    const sourceFillMinStrokePixels = normalizeFillMinStrokePixels(options.sourceFillMinStrokePixels);
    const strokeGapClosePixels = normalizeGapClosePixels(options.strokeGapClosePixels);
    const sourceMask = removeScanlineArtifacts(closeMask(inkMask, width, height, strokeGapClosePixels), width, height);
    const visited = new Uint8Array(sourceMask.length);
    const queue = new Int32Array(sourceMask.length);
    const sourceFillMask = new Uint8Array(sourceMask.length);
    const strokeMask = new Uint8Array(sourceMask.length);
    function enqueue(index, tail) {
        if (visited[index] || !sourceMask[index]) return tail;
        visited[index] = 1;
        queue[tail] = index;
        return tail + 1;
    }
    for(let start = 0; start < sourceMask.length; start += 1){
        if (visited[start] || !sourceMask[start]) continue;
        let head = 0;
        let tail = 0;
        let minX = width;
        let minY = height;
        let maxX = -1;
        let maxY = -1;
        tail = enqueue(start, tail);
        while(head < tail){
            const index = queue[head];
            head += 1;
            const x = index % width;
            const y = Math.floor(index / width);
            minX = Math.min(minX, x);
            minY = Math.min(minY, y);
            maxX = Math.max(maxX, x);
            maxY = Math.max(maxY, y);
            for(let yy = Math.max(0, y - 1); yy <= Math.min(height - 1, y + 1); yy += 1){
                for(let xx = Math.max(0, x - 1); xx <= Math.min(width - 1, x + 1); xx += 1){
                    tail = enqueue(yy * width + xx, tail);
                }
            }
        }
        const bounds = {
            x: minX,
            y: minY,
            width: Math.max(1, maxX - minX + 1),
            height: Math.max(1, maxY - minY + 1)
        };
        if (isScanlineComponent(width, height, bounds)) continue;
        if (isSolidFillComponent(width, queue, tail, bounds, sourceFillThreshold)) {
            paintComponent(width, queue, tail, bounds, createLocalComponentMask(width, queue, tail, bounds), sourceFillMask, strokeMask);
            continue;
        }
        paintComponent(width, queue, tail, bounds, fillMaskForWideStrokes(width, queue, tail, bounds, sourceFillThreshold, sourceFillMinStrokePixels), sourceFillMask, strokeMask);
    }
    const thinnedStrokeMask = thinMask(strokeMask, width, height);
    const fillMask = new Uint8Array(sourceMask.length);
    const enclosedFillMask = enclosedRegionMask(sourceMask, width, height);
    for(let index = 0; index < fillMask.length; index += 1){
        fillMask[index] = sourceFillMask[index] || enclosedFillMask[index] ? 1 : 0;
    }
    const fillBoundaryMask = boundaryMask(sourceFillMask, width, height);
    const outlineMask = new Uint8Array(sourceMask.length);
    for(let index = 0; index < outlineMask.length; index += 1){
        outlineMask[index] = thinnedStrokeMask[index] || fillBoundaryMask[index] ? 1 : 0;
    }
    return {
        enclosedFillMask,
        fillMask,
        outlineMask,
        sourceFillMask,
        strokeMask: thinnedStrokeMask
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/editor/source-layout.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ROTATION_STEP_DEGREES",
    ()=>ROTATION_STEP_DEGREES,
    "applyUnlockedSourcePatch",
    ()=>applyUnlockedSourcePatch,
    "canChangeSourcePosition",
    ()=>canChangeSourcePosition,
    "normalizeRotationDegrees",
    ()=>normalizeRotationDegrees,
    "snapCellToGrid",
    ()=>snapCellToGrid,
    "sourceLayouts",
    ()=>sourceLayouts,
    "sourceProcessingCacheKey",
    ()=>sourceProcessingCacheKey,
    "stackEndCell",
    ()=>stackEndCell
]);
const ROTATION_STEP_DEGREES = 15;
function sourceLayouts(sources) {
    return sources.map((source)=>({
            source,
            x: source.x,
            y: source.y,
            width: source.width,
            height: source.height
        }));
}
function stackEndCell(sources) {
    const layouts = sourceLayouts(sources);
    if (!layouts.length) return 0;
    return Math.max(...layouts.map((layout)=>layout.y + layout.height + layout.source.bottomPadding));
}
function normalizeRotationDegrees(value) {
    const numeric = Number(value);
    if (!Number.isFinite(numeric)) return 0;
    return (Math.round(numeric / ROTATION_STEP_DEGREES) * ROTATION_STEP_DEGREES % 360 + 360) % 360;
}
function snapCellToGrid(value, gridStep = 0.5) {
    if (!Number.isFinite(value)) return 0;
    const step = Math.max(0.1, gridStep);
    return Math.round(Math.round(value / step) * step * 100) / 100;
}
function sourceProcessingCacheKey(source, layout) {
    return [
        source.id,
        source.path ?? "",
        source.url ?? "",
        layout.x,
        layout.y,
        layout.width,
        layout.height,
        source.rotationDegrees,
        source.flipX ? 1 : 0,
        source.flipY ? 1 : 0,
        source.imageLineThickness,
        source.sourceFillThreshold,
        source.sourceFillMinStrokePixels,
        source.strokeGapClosePixels
    ].join("|");
}
function canChangeSourcePosition(source) {
    return !source.locked;
}
function applyUnlockedSourcePatch(source, patch) {
    if (source.locked) return source;
    return {
        ...source,
        ...patch
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/graph-paper.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DEFAULT_CELL_SIZE_CM",
    ()=>DEFAULT_CELL_SIZE_CM,
    "DEFAULT_GRAPH_HEIGHT_CELLS",
    ()=>DEFAULT_GRAPH_HEIGHT_CELLS,
    "DEFAULT_GRAPH_LINE_LAYER",
    ()=>DEFAULT_GRAPH_LINE_LAYER,
    "DEFAULT_GRAPH_WIDTH_CELLS",
    ()=>DEFAULT_GRAPH_WIDTH_CELLS,
    "DEFAULT_GRID_LINE_COLOR",
    ()=>DEFAULT_GRID_LINE_COLOR,
    "DEFAULT_IMAGE_HEIGHT_CELLS",
    ()=>DEFAULT_IMAGE_HEIGHT_CELLS,
    "DEFAULT_IMAGE_LINE_THICKNESS",
    ()=>DEFAULT_IMAGE_LINE_THICKNESS,
    "DEFAULT_IMAGE_PADDING_CELLS",
    ()=>DEFAULT_IMAGE_PADDING_CELLS,
    "DEFAULT_IMAGE_PADDING_PIXELS",
    ()=>DEFAULT_IMAGE_PADDING_PIXELS,
    "DEFAULT_IMAGE_WIDTH_CELLS",
    ()=>DEFAULT_IMAGE_WIDTH_CELLS,
    "DEFAULT_OUTLINE_COLOR",
    ()=>DEFAULT_OUTLINE_COLOR,
    "DEFAULT_PRINT_HORIZONTAL_ALIGNMENT",
    ()=>DEFAULT_PRINT_HORIZONTAL_ALIGNMENT,
    "DEFAULT_PRINT_ORIENTATION",
    ()=>DEFAULT_PRINT_ORIENTATION,
    "DEFAULT_PRINT_PAPER_SIZE",
    ()=>DEFAULT_PRINT_PAPER_SIZE,
    "DEFAULT_PRINT_VERTICAL_ALIGNMENT",
    ()=>DEFAULT_PRINT_VERTICAL_ALIGNMENT,
    "DEFAULT_SOURCE_FILL_MIN_STROKE_PIXELS",
    ()=>DEFAULT_SOURCE_FILL_MIN_STROKE_PIXELS,
    "DEFAULT_SOURCE_FILL_THRESHOLD",
    ()=>DEFAULT_SOURCE_FILL_THRESHOLD,
    "DEFAULT_STROKE_GAP_CLOSE_PIXELS",
    ()=>DEFAULT_STROKE_GAP_CLOSE_PIXELS,
    "GRAPH_LINE_LAYER_KEYS",
    ()=>GRAPH_LINE_LAYER_KEYS,
    "GRAPH_MAJOR_CELL_PIXELS",
    ()=>GRAPH_MAJOR_CELL_PIXELS,
    "GRAPH_MINOR_PIXEL_SIZE",
    ()=>GRAPH_MINOR_PIXEL_SIZE,
    "GRAPH_SUBDIVISIONS",
    ()=>GRAPH_SUBDIVISIONS,
    "MAX_IMAGE_LINE_THICKNESS",
    ()=>MAX_IMAGE_LINE_THICKNESS,
    "MAX_IMAGE_PADDING_PIXELS",
    ()=>MAX_IMAGE_PADDING_PIXELS,
    "MAX_SOURCE_FILL_MIN_STROKE_PIXELS",
    ()=>MAX_SOURCE_FILL_MIN_STROKE_PIXELS,
    "MAX_SOURCE_FILL_THRESHOLD",
    ()=>MAX_SOURCE_FILL_THRESHOLD,
    "MAX_STROKE_GAP_CLOSE_PIXELS",
    ()=>MAX_STROKE_GAP_CLOSE_PIXELS,
    "MIN_IMAGE_LINE_THICKNESS",
    ()=>MIN_IMAGE_LINE_THICKNESS,
    "MIN_SOURCE_FILL_MIN_STROKE_PIXELS",
    ()=>MIN_SOURCE_FILL_MIN_STROKE_PIXELS,
    "MIN_SOURCE_FILL_THRESHOLD",
    ()=>MIN_SOURCE_FILL_THRESHOLD,
    "MIN_STROKE_GAP_CLOSE_PIXELS",
    ()=>MIN_STROKE_GAP_CLOSE_PIXELS,
    "PRESET_GRAPH_COLORS",
    ()=>PRESET_GRAPH_COLORS,
    "PRESET_GRAPH_LINE_COLORS",
    ()=>PRESET_GRAPH_LINE_COLORS,
    "PRINT_HORIZONTAL_ALIGNMENT_KEYS",
    ()=>PRINT_HORIZONTAL_ALIGNMENT_KEYS,
    "PRINT_ORIENTATION_KEYS",
    ()=>PRINT_ORIENTATION_KEYS,
    "PRINT_PAPER_SIZES",
    ()=>PRINT_PAPER_SIZES,
    "PRINT_PAPER_SIZE_KEYS",
    ()=>PRINT_PAPER_SIZE_KEYS,
    "PRINT_VERTICAL_ALIGNMENT_KEYS",
    ()=>PRINT_VERTICAL_ALIGNMENT_KEYS,
    "TRANSPARENT_FILL_COLOR",
    ()=>TRANSPARENT_FILL_COLOR,
    "clampImageLineThickness",
    ()=>clampImageLineThickness,
    "clampSourceFillMinStrokePixels",
    ()=>clampSourceFillMinStrokePixels,
    "clampSourceFillThreshold",
    ()=>clampSourceFillThreshold,
    "clampStrokeGapClosePixels",
    ()=>clampStrokeGapClosePixels,
    "isFillColor",
    ()=>isFillColor,
    "isGraphLineLayer",
    ()=>isGraphLineLayer,
    "isHexColor",
    ()=>isHexColor,
    "isPrintHorizontalAlignment",
    ()=>isPrintHorizontalAlignment,
    "isPrintOrientation",
    ()=>isPrintOrientation,
    "isPrintPaperSize",
    ()=>isPrintPaperSize,
    "isPrintVerticalAlignment",
    ()=>isPrintVerticalAlignment,
    "isTransparentFillColor",
    ()=>isTransparentFillColor,
    "lightenColor",
    ()=>lightenColor
]);
const GRAPH_SUBDIVISIONS = 10;
const GRAPH_MINOR_PIXEL_SIZE = 4;
const GRAPH_MAJOR_CELL_PIXELS = GRAPH_SUBDIVISIONS * GRAPH_MINOR_PIXEL_SIZE;
const MAX_IMAGE_PADDING_PIXELS = 1200;
const DEFAULT_IMAGE_PADDING_CELLS = 2;
const DEFAULT_IMAGE_PADDING_PIXELS = DEFAULT_IMAGE_PADDING_CELLS * GRAPH_MINOR_PIXEL_SIZE;
const DEFAULT_CELL_SIZE_CM = 1;
const DEFAULT_GRAPH_WIDTH_CELLS = 10;
const DEFAULT_GRAPH_HEIGHT_CELLS = 112;
const DEFAULT_IMAGE_WIDTH_CELLS = 8;
const DEFAULT_IMAGE_HEIGHT_CELLS = 10;
const DEFAULT_IMAGE_LINE_THICKNESS = 0;
const MIN_IMAGE_LINE_THICKNESS = 0;
const MAX_IMAGE_LINE_THICKNESS = 6;
const DEFAULT_SOURCE_FILL_THRESHOLD = 0.58;
const MIN_SOURCE_FILL_THRESHOLD = 0.05;
const MAX_SOURCE_FILL_THRESHOLD = 1;
const DEFAULT_SOURCE_FILL_MIN_STROKE_PIXELS = 7;
const MIN_SOURCE_FILL_MIN_STROKE_PIXELS = 2;
const MAX_SOURCE_FILL_MIN_STROKE_PIXELS = 48;
const DEFAULT_STROKE_GAP_CLOSE_PIXELS = 0;
const MIN_STROKE_GAP_CLOSE_PIXELS = 0;
const MAX_STROKE_GAP_CLOSE_PIXELS = 2;
const DEFAULT_OUTLINE_COLOR = "#111827";
const DEFAULT_GRID_LINE_COLOR = "#dc2626";
const TRANSPARENT_FILL_COLOR = "transparent";
const GRAPH_LINE_LAYER_KEYS = [
    "front",
    "back"
];
const DEFAULT_GRAPH_LINE_LAYER = "back";
const PRINT_PAPER_SIZE_KEYS = [
    "a4",
    "a3",
    "letter",
    "legal",
    "tabloid"
];
const DEFAULT_PRINT_PAPER_SIZE = "a4";
const PRINT_ORIENTATION_KEYS = [
    "auto",
    "portrait",
    "landscape"
];
const DEFAULT_PRINT_ORIENTATION = "auto";
const PRINT_HORIZONTAL_ALIGNMENT_KEYS = [
    "left",
    "center",
    "right"
];
const DEFAULT_PRINT_HORIZONTAL_ALIGNMENT = "center";
const PRINT_VERTICAL_ALIGNMENT_KEYS = [
    "top",
    "center",
    "bottom"
];
const DEFAULT_PRINT_VERTICAL_ALIGNMENT = "center";
const PRINT_PAPER_SIZES = {
    a4: {
        label: "A4",
        widthCm: 21,
        heightCm: 29.7
    },
    a3: {
        label: "A3",
        widthCm: 29.7,
        heightCm: 42
    },
    letter: {
        label: "Letter",
        widthCm: 21.59,
        heightCm: 27.94
    },
    legal: {
        label: "Legal",
        widthCm: 21.59,
        heightCm: 35.56
    },
    tabloid: {
        label: "Tabloid",
        widthCm: 27.94,
        heightCm: 43.18
    }
};
function isPrintPaperSize(value) {
    return typeof value === "string" && PRINT_PAPER_SIZE_KEYS.includes(value);
}
function isGraphLineLayer(value) {
    return typeof value === "string" && GRAPH_LINE_LAYER_KEYS.includes(value);
}
function isPrintOrientation(value) {
    return typeof value === "string" && PRINT_ORIENTATION_KEYS.includes(value);
}
function isPrintHorizontalAlignment(value) {
    return typeof value === "string" && PRINT_HORIZONTAL_ALIGNMENT_KEYS.includes(value);
}
function isPrintVerticalAlignment(value) {
    return typeof value === "string" && PRINT_VERTICAL_ALIGNMENT_KEYS.includes(value);
}
const PRESET_GRAPH_COLORS = [
    {
        name: "White",
        hex: "#ffffff"
    },
    {
        name: "Black",
        hex: "#111827"
    },
    {
        name: "Slate",
        hex: "#334155"
    },
    {
        name: "Gray",
        hex: "#6b7280"
    },
    {
        name: "Zinc",
        hex: "#71717a"
    },
    {
        name: "Red",
        hex: "#dc2626"
    },
    {
        name: "Crimson",
        hex: "#be123c"
    },
    {
        name: "Rose",
        hex: "#e11d48"
    },
    {
        name: "Pink",
        hex: "#db2777"
    },
    {
        name: "Fuchsia",
        hex: "#c026d3"
    },
    {
        name: "Purple",
        hex: "#9333ea"
    },
    {
        name: "Violet",
        hex: "#7c3aed"
    },
    {
        name: "Indigo",
        hex: "#4f46e5"
    },
    {
        name: "Blue",
        hex: "#2563eb"
    },
    {
        name: "Navy",
        hex: "#1e3a8a"
    },
    {
        name: "Sky",
        hex: "#0284c7"
    },
    {
        name: "Cyan",
        hex: "#0891b2"
    },
    {
        name: "Teal",
        hex: "#0f766e"
    },
    {
        name: "Emerald",
        hex: "#059669"
    },
    {
        name: "Green",
        hex: "#16a34a"
    },
    {
        name: "Lime",
        hex: "#65a30d"
    },
    {
        name: "Olive",
        hex: "#4d7c0f"
    },
    {
        name: "Yellow",
        hex: "#ca8a04"
    },
    {
        name: "Gold",
        hex: "#d97706"
    },
    {
        name: "Amber",
        hex: "#f59e0b"
    },
    {
        name: "Orange",
        hex: "#ea580c"
    },
    {
        name: "Coral",
        hex: "#f97316"
    },
    {
        name: "Brown",
        hex: "#92400e"
    },
    {
        name: "Maroon",
        hex: "#7f1d1d"
    },
    {
        name: "Mint",
        hex: "#2dd4bf"
    },
    {
        name: "Lavender",
        hex: "#a78bfa"
    }
];
const PRESET_GRAPH_LINE_COLORS = [
    {
        name: "Red",
        hex: DEFAULT_GRID_LINE_COLOR
    },
    {
        name: "Green",
        hex: "#16a34a"
    },
    {
        name: "Blue",
        hex: "#2563eb"
    },
    {
        name: "Purple",
        hex: "#9333ea"
    },
    {
        name: "Orange",
        hex: "#ea580c"
    },
    {
        name: "Black",
        hex: "#111827"
    },
    {
        name: "Gray",
        hex: "#64748b"
    }
];
function isHexColor(value) {
    return typeof value === "string" && /^#[0-9A-Fa-f]{6}$/.test(value);
}
function isTransparentFillColor(value) {
    return value === TRANSPARENT_FILL_COLOR;
}
function isFillColor(value) {
    return isHexColor(value) || isTransparentFillColor(value);
}
function clampImageLineThickness(value) {
    const numeric = Number(value);
    if (!Number.isFinite(numeric)) return DEFAULT_IMAGE_LINE_THICKNESS;
    return Math.round(Math.max(MIN_IMAGE_LINE_THICKNESS, Math.min(MAX_IMAGE_LINE_THICKNESS, numeric)) * 1000) / 1000;
}
function clampSourceFillThreshold(value) {
    const numeric = Number(value);
    if (!Number.isFinite(numeric)) return DEFAULT_SOURCE_FILL_THRESHOLD;
    return Math.round(Math.max(MIN_SOURCE_FILL_THRESHOLD, Math.min(MAX_SOURCE_FILL_THRESHOLD, numeric)) * 1000) / 1000;
}
function clampSourceFillMinStrokePixels(value) {
    const numeric = Number(value);
    if (!Number.isFinite(numeric)) return DEFAULT_SOURCE_FILL_MIN_STROKE_PIXELS;
    return Math.round(Math.max(MIN_SOURCE_FILL_MIN_STROKE_PIXELS, Math.min(MAX_SOURCE_FILL_MIN_STROKE_PIXELS, numeric)));
}
function clampStrokeGapClosePixels(value) {
    const numeric = Number(value);
    if (!Number.isFinite(numeric)) return DEFAULT_STROKE_GAP_CLOSE_PIXELS;
    return Math.round(Math.max(MIN_STROKE_GAP_CLOSE_PIXELS, Math.min(MAX_STROKE_GAP_CLOSE_PIXELS, numeric)));
}
function lightenColor(hex, amount = 0.72) {
    const clean = isHexColor(hex) ? hex.slice(1) : DEFAULT_OUTLINE_COLOR.slice(1);
    const channels = [
        clean.slice(0, 2),
        clean.slice(2, 4),
        clean.slice(4, 6)
    ].map((channel)=>Number.parseInt(channel, 16));
    const value = channels.map((channel)=>Math.round(channel + (255 - channel) * amount).toString(16).padStart(2, "0")).join("");
    return `#${value}`;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/canvas/processor.worker.ts (static in ecmascript, tag client)", ((__turbopack_context__) => {

__turbopack_context__.q("/_next/static/media/processor.worker.24m2swdyni9qf.ts");}),
"[project]/src/lib/canvas/processor.worker.ts [app-client] (ecmascript, worker loader)", ((__turbopack_context__) => {

__turbopack_context__.v(function(Ctor, opts) {
    return __turbopack_context__.b(Ctor, "static/chunks/turbopack-worker-[client-fs]__next_static_chunks_1_hyozq._.js", ["static/chunks/node_modules_pdfjs-dist_build_pdf_mjs_0urn6q8._.js","static/chunks/_0fge0po._.js","static/chunks/src_lib_canvas_processor_worker_ts_1gdnjqz._.js","static/chunks/turbopack-src_lib_canvas_processor_worker_ts_05n7jp4._.js"], opts);
});
}),
"[project]/src/lib/canvas/processor.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "findContentBounds",
    ()=>findContentBounds,
    "generateGridOverlay",
    ()=>generateGridOverlay,
    "loadImageToCanvas",
    ()=>loadImageToCanvas,
    "pixelateImage",
    ()=>pixelateImage,
    "pixelateImageWithWorker",
    ()=>pixelateImageWithWorker,
    "pixelateLayeredCanvases",
    ()=>pixelateLayeredCanvases,
    "pixelateLayeredImages",
    ()=>pixelateLayeredImages,
    "pixelateLayeredImagesWithWorker",
    ()=>pixelateLayeredImagesWithWorker,
    "resizeImage",
    ()=>resizeImage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$color$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/canvas/color.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$grid$2d$numbering$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/canvas/grid-numbering.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$ink$2d$mask$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/canvas/ink-mask.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$pdf$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/canvas/pdf.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$thinning$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/canvas/thinning.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$editor$2f$source$2d$layout$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/editor/source-layout.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$graph$2d$paper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/graph-paper.ts [app-client] (ecmascript)");
const __TURBOPACK__import$2e$meta__ = {
    get url () {
        return `file://${__turbopack_context__.P("src/lib/canvas/processor.ts")}`;
    },
    get turbopackHot () {
        return __turbopack_context__.m.hot;
    }
};
;
;
;
;
;
;
;
const contentBoundsCache = new WeakMap();
function createProcessingCanvas(width, height) {
    const safeWidth = Math.max(1, Math.round(width));
    const safeHeight = Math.max(1, Math.round(height));
    if (typeof document !== "undefined") {
        const canvas = document.createElement("canvas");
        canvas.width = safeWidth;
        canvas.height = safeHeight;
        return canvas;
    }
    return new OffscreenCanvas(safeWidth, safeHeight);
}
function getProcessingContext(canvas, options) {
    return canvas.getContext("2d", options);
}
function graphDimensions(settings) {
    const graphWidth = Math.max(1, Math.round(settings.graphWidth || 1));
    const graphHeight = Math.max(1, Math.round(settings.graphHeight || 1));
    const cellWidth = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$graph$2d$paper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GRAPH_MAJOR_CELL_PIXELS"];
    const cellHeight = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$graph$2d$paper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GRAPH_MAJOR_CELL_PIXELS"];
    const imageAreaWidth = graphWidth * cellWidth;
    const imageAreaHeight = graphHeight * cellHeight;
    const imageWidth = Math.max(1, Math.min(imageAreaWidth, Math.round(Number(settings.imageWidth || graphWidth) * cellWidth)));
    const imageHeight = Math.max(1, Math.min(imageAreaHeight, Math.round(Number(settings.imageHeight || graphHeight) * cellHeight)));
    const outputWidth = imageAreaWidth;
    const outputHeight = imageAreaHeight;
    return {
        cellWidth,
        cellHeight,
        graphWidth,
        graphHeight,
        imageWidth,
        imageHeight,
        imageAreaWidth,
        imageAreaHeight,
        minorWidth: cellWidth / __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$graph$2d$paper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GRAPH_SUBDIVISIONS"],
        minorHeight: cellHeight / __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$graph$2d$paper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GRAPH_SUBDIVISIONS"],
        outputWidth,
        outputHeight
    };
}
async function loadImageToCanvas(fileOrUrl, fileName) {
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$pdf$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPdfSource"])(fileOrUrl, fileName)) {
        return (await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$pdf$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["renderPdfFirstPageToCanvas"])(fileOrUrl)).canvas;
    }
    const url = typeof fileOrUrl === "string" ? fileOrUrl : URL.createObjectURL(fileOrUrl);
    try {
        const image = await new Promise((resolve, reject)=>{
            const img = new Image();
            img.crossOrigin = "anonymous";
            img.onload = ()=>resolve(img);
            img.onerror = reject;
            img.src = url;
        });
        const canvas = document.createElement("canvas");
        canvas.width = image.naturalWidth || image.width;
        canvas.height = image.naturalHeight || image.height;
        const context = canvas.getContext("2d", {
            willReadFrequently: true
        });
        if (!context) throw new Error("Canvas is not available.");
        context.drawImage(image, 0, 0);
        return canvas;
    } finally{
        if (typeof fileOrUrl !== "string") URL.revokeObjectURL(url);
    }
}
function resizeImage(canvas, maxWidth, maxHeight) {
    const ratio = Math.min(1, maxWidth / canvas.width, maxHeight / canvas.height);
    if (ratio >= 1) return canvas;
    const output = document.createElement("canvas");
    output.width = Math.max(1, Math.round(canvas.width * ratio));
    output.height = Math.max(1, Math.round(canvas.height * ratio));
    const context = output.getContext("2d", {
        willReadFrequently: true
    });
    if (!context) throw new Error("Canvas is not available.");
    context.imageSmoothingEnabled = true;
    context.imageSmoothingQuality = "high";
    context.drawImage(canvas, 0, 0, output.width, output.height);
    return output;
}
function fitCanvas(canvas, settings) {
    const dimensions = graphDimensions(settings);
    const width = dimensions.outputWidth;
    const height = dimensions.outputHeight;
    const contentBounds = findContentBounds(canvas);
    const output = createProcessingCanvas(width, height);
    const context = getProcessingContext(output, {
        willReadFrequently: true
    });
    if (!context) throw new Error("Canvas is not available.");
    context.clearRect(0, 0, width, height);
    context.imageSmoothingEnabled = true;
    context.imageSmoothingQuality = "high";
    const drawWidth = dimensions.imageWidth;
    const drawHeight = dimensions.imageHeight;
    const x = Math.round((dimensions.imageAreaWidth - drawWidth) / 2) + Math.round(settings.imageOffsetX ?? 0);
    const y = Math.round((dimensions.imageAreaHeight - drawHeight) / 2) + Math.round(settings.imageOffsetY ?? 0);
    context.drawImage(canvas, contentBounds.x, contentBounds.y, contentBounds.width, contentBounds.height, x, y, drawWidth, drawHeight);
    return output;
}
function findContentBounds(canvas) {
    const cached = contentBoundsCache.get(canvas);
    if (cached) return cached;
    const context = getProcessingContext(canvas, {
        willReadFrequently: true
    });
    if (!context) throw new Error("Canvas is not available.");
    const imageData = context.getImageData(0, 0, canvas.width, canvas.height);
    const data = imageData.data;
    let minX = canvas.width;
    let minY = canvas.height;
    let maxX = -1;
    let maxY = -1;
    for(let y = 0; y < canvas.height; y += 1){
        for(let x = 0; x < canvas.width; x += 1){
            const index = (y * canvas.width + x) * 4;
            const alpha = data[index + 3];
            if (alpha < 16) continue;
            const isNearWhite = data[index] >= 250 && data[index + 1] >= 250 && data[index + 2] >= 250;
            if (isNearWhite) continue;
            minX = Math.min(minX, x);
            minY = Math.min(minY, y);
            maxX = Math.max(maxX, x);
            maxY = Math.max(maxY, y);
        }
    }
    if (maxX < minX || maxY < minY) {
        const fullBounds = {
            x: 0,
            y: 0,
            width: canvas.width,
            height: canvas.height
        };
        contentBoundsCache.set(canvas, fullBounds);
        return fullBounds;
    }
    const contentMargin = 2;
    const x = Math.max(0, minX - contentMargin);
    const y = Math.max(0, minY - contentMargin);
    const right = Math.min(canvas.width - 1, maxX + contentMargin);
    const bottom = Math.min(canvas.height - 1, maxY + contentMargin);
    const bounds = {
        x,
        y,
        width: Math.max(1, right - x + 1),
        height: Math.max(1, bottom - y + 1)
    };
    contentBoundsCache.set(canvas, bounds);
    return bounds;
}
function buildArtworkMasks(imageData, settings) {
    const width = imageData.width;
    const height = imageData.height;
    const { mask: inkMask } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$ink$2d$mask$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["maskFromImageData"])(imageData);
    const masks = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$thinning$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createThinArtworkMasks"])(inkMask, width, height, {
        sourceFillThreshold: settings.sourceFillThreshold,
        sourceFillMinStrokePixels: settings.sourceFillMinStrokePixels,
        strokeGapClosePixels: settings.strokeGapClosePixels
    });
    const imageLineThickness = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$graph$2d$paper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clampImageLineThickness"])(settings.imageLineThickness);
    const outlineMask = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$thinning$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["expandMaskForLineSize"])(masks.outlineMask, width, height, imageLineThickness);
    return {
        enclosedFillMask: masks.enclosedFillMask,
        fillMask: masks.fillMask,
        outlineMask,
        sourceFillMask: masks.sourceFillMask
    };
}
function defaultFillColorForRegion(settings, kind) {
    return kind === "source" ? settings.outlineColor || settings.lineColor : settings.fillColor;
}
function fillColorForRegion(settings, regionId, kind) {
    const customColor = settings.fillRegions?.[regionId];
    return customColor && (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$graph$2d$paper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isFillColor"])(customColor) ? customColor : defaultFillColorForRegion(settings, kind);
}
function labelFillRegions(fillLayers, width, height, settings) {
    const fillRegionMap = new Uint16Array(width * height);
    const queue = new Int32Array(fillRegionMap.length);
    const regions = [];
    let nextRegionId = 0;
    for (const { mask: fillMask, kind } of fillLayers){
        const visited = new Uint8Array(fillMask.length);
        for(let start = 0; start < fillMask.length; start += 1){
            if (!fillMask[start] || visited[start] || fillRegionMap[start] || nextRegionId >= 65535) continue;
            nextRegionId += 1;
            let head = 0;
            let tail = 0;
            let count = 0;
            let sumX = 0;
            let sumY = 0;
            const regionId = String(nextRegionId);
            visited[start] = 1;
            fillRegionMap[start] = nextRegionId;
            queue[tail] = start;
            tail += 1;
            while(head < tail){
                const index = queue[head];
                head += 1;
                count += 1;
                const x = index % width;
                const y = Math.floor(index / width);
                sumX += x;
                sumY += y;
                function enqueue(next) {
                    if (!fillMask[next] || visited[next] || fillRegionMap[next]) return;
                    visited[next] = 1;
                    fillRegionMap[next] = nextRegionId;
                    queue[tail] = next;
                    tail += 1;
                }
                if (x > 0) enqueue(index - 1);
                if (x < width - 1) enqueue(index + 1);
                if (y > 0) enqueue(index - width);
                if (y < height - 1) enqueue(index + width);
            }
            regions.push({
                id: regionId,
                color: fillColorForRegion(settings, regionId, kind),
                cellCount: count,
                centerX: count ? Math.round(sumX / count) : 0,
                centerY: count ? Math.round(sumY / count) : 0,
                kind
            });
        }
    }
    return {
        fillRegionMap,
        regions
    };
}
function createMaskLayer(mask, width, height, color, alpha = 255) {
    const canvas = createProcessingCanvas(width, height);
    const context = getProcessingContext(canvas, {
        willReadFrequently: true
    });
    if (!context) throw new Error("Canvas is not available.");
    const rgb = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$color$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hexToRgb"])(color);
    const imageData = context.createImageData(width, height);
    const data = imageData.data;
    for(let pixel = 0, index = 0; pixel < mask.length; pixel += 1, index += 4){
        if (!mask[pixel]) continue;
        data[index] = rgb.r;
        data[index + 1] = rgb.g;
        data[index + 2] = rgb.b;
        data[index + 3] = alpha;
    }
    context.putImageData(imageData, 0, 0);
    return canvas;
}
function drawFillRegions(context, fillRegionMap, regions, width, height, settings, blurRadius) {
    const layer = createProcessingCanvas(width, height);
    const layerContext = getProcessingContext(layer, {
        willReadFrequently: true
    });
    if (!layerContext) throw new Error("Canvas is not available.");
    const colorCache = new Map();
    const regionByNumber = new Map(regions.map((region)=>[
            Number(region.id),
            region
        ]));
    const imageData = layerContext.createImageData(width, height);
    const data = imageData.data;
    for(let pixel = 0, index = 0; pixel < fillRegionMap.length; pixel += 1, index += 4){
        const regionNumber = fillRegionMap[pixel];
        if (!regionNumber) continue;
        const region = regionByNumber.get(regionNumber);
        if (!region) continue;
        const hex = fillColorForRegion(settings, region.id, region.kind);
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$graph$2d$paper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isTransparentFillColor"])(hex)) continue;
        let rgb = colorCache.get(hex);
        if (!rgb) {
            rgb = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$color$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hexToRgb"])(hex);
            colorCache.set(hex, rgb);
        }
        data[index] = rgb.r;
        data[index + 1] = rgb.g;
        data[index + 2] = rgb.b;
        data[index + 3] = 255;
    }
    layerContext.putImageData(imageData, 0, 0);
    if (blurRadius <= 0) {
        context.drawImage(layer, 0, 0);
        return;
    }
    const softened = createProcessingCanvas(width, height);
    const softenedContext = getProcessingContext(softened);
    if (!softenedContext) throw new Error("Canvas is not available.");
    softenedContext.filter = `blur(${blurRadius}px)`;
    softenedContext.drawImage(layer, 0, 0);
    context.drawImage(softened, 0, 0);
}
function drawMaskLayer(context, mask, width, height, color, alpha, blurRadius) {
    const layer = createMaskLayer(mask, width, height, color, alpha);
    if (blurRadius <= 0) {
        context.drawImage(layer, 0, 0);
        return;
    }
    const softened = createProcessingCanvas(width, height);
    const softenedContext = getProcessingContext(softened);
    if (!softenedContext) throw new Error("Canvas is not available.");
    softenedContext.filter = `blur(${blurRadius}px)`;
    softenedContext.drawImage(layer, 0, 0);
    context.drawImage(softened, 0, 0);
}
function drawGraphPaperGrid(canvas, settings) {
    const context = getProcessingContext(canvas);
    if (!context) throw new Error("Canvas is not available.");
    const dimensions = graphDimensions(settings);
    const minorWidth = dimensions.minorWidth;
    const minorHeight = dimensions.minorHeight;
    const columns = Math.max(1, Math.round(dimensions.outputWidth / minorWidth));
    const rows = Math.max(1, Math.round(dimensions.outputHeight / minorHeight));
    const minorLineWidth = 1;
    const midLineWidth = 1;
    const majorLineWidth = 2;
    const gridColor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$color$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hexToRgb"])(settings.gridLineColor || __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$graph$2d$paper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_GRID_LINE_COLOR"]);
    context.save();
    context.fillStyle = `rgb(${gridColor.r}, ${gridColor.g}, ${gridColor.b})`;
    function lineProfileForIndex(index) {
        if (index % __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$graph$2d$paper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GRAPH_SUBDIVISIONS"] === 0) return {
            width: majorLineWidth,
            alpha: 0.72
        };
        if (index % 5 === 0) return {
            width: midLineWidth,
            alpha: 0.52
        };
        return {
            width: minorLineWidth,
            alpha: 0.34
        };
    }
    function lineStart(index, count, spacing, lineWidth, limit) {
        if (index === 0) return 0;
        if (index === count) return Math.max(0, limit - lineWidth);
        return Math.round(index * spacing - lineWidth / 2);
    }
    for(let column = 0; column <= columns; column += 1){
        const line = lineProfileForIndex(column);
        const x = lineStart(column, columns, minorWidth, line.width, canvas.width);
        context.globalAlpha = line.alpha;
        context.fillRect(x, 0, line.width, canvas.height);
    }
    for(let row = 0; row <= rows; row += 1){
        const line = lineProfileForIndex(row);
        const y = lineStart(row, rows, minorHeight, line.width, canvas.height);
        context.globalAlpha = line.alpha;
        context.fillRect(0, y, canvas.width, line.width);
    }
    context.restore();
}
function drawGridNumbers(canvas, settings) {
    if (!settings.showNumbers || settings.gridNumberPlacement === "outside") return;
    const context = getProcessingContext(canvas);
    if (!context) throw new Error("Canvas is not available.");
    const ctx = context;
    const dimensions = graphDimensions(settings);
    const labels = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$grid$2d$numbering$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createGridNumberLabels"])(dimensions.graphWidth, dimensions.graphHeight, dimensions.cellWidth, dimensions.cellHeight);
    const gridColor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$color$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hexToRgb"])(settings.gridLineColor || __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$graph$2d$paper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_GRID_LINE_COLOR"]);
    const fontSize = Math.max(8, Math.min(13, Math.round(dimensions.cellWidth * 0.28)));
    ctx.save();
    ctx.font = `600 ${fontSize}px Arial, sans-serif`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.lineWidth = 3;
    ctx.strokeStyle = "rgba(255, 255, 255, 0.82)";
    ctx.fillStyle = `rgba(${gridColor.r}, ${gridColor.g}, ${gridColor.b}, 0.78)`;
    function drawLabel(label) {
        const text = String(label.value);
        ctx.strokeText(text, label.x, label.y);
        ctx.fillText(text, label.x, label.y);
    }
    labels.top.forEach(drawLabel);
    labels.bottom.forEach(drawLabel);
    labels.left.forEach(drawLabel);
    labels.right.forEach(drawLabel);
    ctx.restore();
}
function drawManualGraphArtwork(canvas, settings) {
    const context = getProcessingContext(canvas);
    if (!context) throw new Error("Canvas is not available.");
    const cellWidth = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$graph$2d$paper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GRAPH_MAJOR_CELL_PIXELS"];
    const cellHeight = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$graph$2d$paper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GRAPH_MAJOR_CELL_PIXELS"];
    context.save();
    context.lineJoin = "round";
    context.lineCap = "round";
    for (const paint of settings.cellPaints ?? []){
        const left = paint.x * cellWidth;
        const top = paint.y * cellHeight;
        const width = Math.max(1, paint.width * cellWidth);
        const height = Math.max(1, paint.height * cellHeight);
        const right = width / 2;
        const bottom = height / 2;
        const rotation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$editor$2f$source$2d$layout$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeRotationDegrees"])(paint.rotationDegrees);
        context.save();
        context.translate(left + width / 2, top + height / 2);
        context.rotate(rotation * Math.PI / 180);
        context.scale(paint.flipX ? -1 : 1, paint.flipY ? -1 : 1);
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$graph$2d$paper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isTransparentFillColor"])(paint.fillColor)) {
            context.fillStyle = paint.fillColor;
            context.fillRect(-right, -bottom, width, height);
        }
        if (paint.sides.length) {
            context.beginPath();
            context.strokeStyle = paint.lineColor || settings.outlineColor || settings.lineColor;
            context.lineWidth = Math.max(1, Math.min(24, paint.lineWidth || 3));
            if (paint.sides.includes("top")) {
                context.moveTo(-right, -bottom);
                context.lineTo(right, -bottom);
            }
            if (paint.sides.includes("right")) {
                context.moveTo(right, -bottom);
                context.lineTo(right, bottom);
            }
            if (paint.sides.includes("bottom")) {
                context.moveTo(right, bottom);
                context.lineTo(-right, bottom);
            }
            if (paint.sides.includes("left")) {
                context.moveTo(-right, bottom);
                context.lineTo(-right, -bottom);
            }
            context.stroke();
        }
        context.restore();
    }
    for (const shape of settings.graphShapes ?? []){
        const x = shape.x * cellWidth;
        const y = shape.y * cellHeight;
        const width = shape.width * cellWidth;
        const height = shape.height * cellHeight;
        const strokeWidth = Math.max(1, Math.min(24, shape.strokeWidth || 3));
        context.strokeStyle = shape.strokeColor || settings.outlineColor || settings.lineColor;
        context.fillStyle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$graph$2d$paper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isTransparentFillColor"])(shape.fillColor) ? "rgba(0,0,0,0)" : shape.fillColor;
        context.lineWidth = strokeWidth;
        context.save();
        context.translate(x + width / 2, y + height / 2);
        context.rotate((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$editor$2f$source$2d$layout$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeRotationDegrees"])(shape.rotationDegrees) * Math.PI / 180);
        context.scale(shape.flipX ? -1 : 1, shape.flipY ? -1 : 1);
        context.translate(-(x + width / 2), -(y + height / 2));
        context.beginPath();
        if (shape.kind === "line" || shape.kind === "arrow") {
            context.moveTo(x, y);
            context.lineTo(x + width, y + height);
            context.stroke();
            if (shape.kind === "arrow") {
                const angle = Math.atan2(height, width);
                const headLength = Math.max(10, strokeWidth * 4);
                context.beginPath();
                context.moveTo(x + width, y + height);
                context.lineTo(x + width - headLength * Math.cos(angle - Math.PI / 6), y + height - headLength * Math.sin(angle - Math.PI / 6));
                context.moveTo(x + width, y + height);
                context.lineTo(x + width - headLength * Math.cos(angle + Math.PI / 6), y + height - headLength * Math.sin(angle + Math.PI / 6));
                context.stroke();
            }
            context.restore();
            continue;
        }
        const left = Math.min(x, x + width);
        const top = Math.min(y, y + height);
        const rectWidth = Math.max(1, Math.abs(width));
        const rectHeight = Math.max(1, Math.abs(height));
        const squareSize = Math.max(rectWidth, rectHeight);
        const drawWidth = shape.kind === "square" || shape.kind === "circle" ? squareSize : rectWidth;
        const drawHeight = shape.kind === "square" || shape.kind === "circle" ? squareSize : rectHeight;
        const centerX = left + drawWidth / 2;
        const centerY = top + drawHeight / 2;
        if (shape.kind === "circle" || shape.kind === "oval") {
            context.ellipse(centerX, centerY, drawWidth / 2, drawHeight / 2, 0, 0, Math.PI * 2);
        } else {
            context.rect(left, top, drawWidth, drawHeight);
        }
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$graph$2d$paper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isTransparentFillColor"])(shape.fillColor)) context.fill();
        context.stroke();
        context.restore();
    }
    context.restore();
}
function pixelateCanvas(sourceCanvas, settings, options = {}) {
    const fitted = options.sourceIsFitted ? sourceCanvas : fitCanvas(sourceCanvas, settings);
    const fittedContext = getProcessingContext(fitted, {
        willReadFrequently: true
    });
    if (!fittedContext) throw new Error("Canvas is not available.");
    const sourceData = fittedContext.getImageData(0, 0, fitted.width, fitted.height);
    const { enclosedFillMask, outlineMask, sourceFillMask } = buildArtworkMasks(sourceData, settings);
    const { fillRegionMap, regions } = labelFillRegions([
        {
            mask: sourceFillMask,
            kind: "source"
        },
        {
            mask: enclosedFillMask,
            kind: "enclosed"
        }
    ], fitted.width, fitted.height, settings);
    const output = createProcessingCanvas(fitted.width, fitted.height);
    const outputContext = getProcessingContext(output, {
        willReadFrequently: true
    });
    if (!outputContext) throw new Error("Canvas is not available.");
    outputContext.fillStyle = settings.backgroundColor || "#ffffff";
    outputContext.fillRect(0, 0, output.width, output.height);
    if (settings.gridLineLayer === "back") drawGraphPaperGrid(output, settings);
    drawFillRegions(outputContext, fillRegionMap, regions, output.width, output.height, settings, 0.8);
    const imageLineThickness = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$graph$2d$paper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clampImageLineThickness"])(settings.imageLineThickness);
    drawMaskLayer(outputContext, outlineMask, output.width, output.height, settings.outlineColor || settings.lineColor, 255, 0.12 * imageLineThickness);
    if (settings.gridLineLayer !== "back") drawGraphPaperGrid(output, settings);
    drawManualGraphArtwork(output, settings);
    drawGridNumbers(output, settings);
    const outlineHex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$color$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rgbToHex"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$color$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hexToRgb"])(settings.outlineColor || settings.lineColor));
    const outlineCount = outlineMask.reduce((sum, value)=>sum + value, 0);
    const fillCountsByColor = new Map();
    for (const region of regions){
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$graph$2d$paper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isTransparentFillColor"])(region.color)) continue;
        const hex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$color$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rgbToHex"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$color$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hexToRgb"])(region.color));
        fillCountsByColor.set(hex, (fillCountsByColor.get(hex) ?? 0) + region.cellCount);
    }
    return {
        canvas: output,
        palette: [
            {
                name: "Outline",
                hex: outlineHex,
                locked: true,
                cellCount: outlineCount,
                sortOrder: 0
            },
            ...Array.from(fillCountsByColor.entries()).map(([hex, cellCount], index)=>({
                    name: index === 0 ? "Fill" : `Fill ${index + 1}`,
                    hex,
                    locked: true,
                    cellCount,
                    sortOrder: index + 1
                }))
        ],
        fillRegions: regions,
        fillRegionMap
    };
}
function pixelateImage(sourceCanvas, settings, options = {}) {
    return pixelateCanvas(sourceCanvas, settings, options);
}
function pixelateLayeredCanvases(layers, settings) {
    const dimensions = graphDimensions(settings);
    const width = dimensions.outputWidth;
    const height = dimensions.outputHeight;
    const output = createProcessingCanvas(width, height);
    const outputContext = getProcessingContext(output, {
        willReadFrequently: true
    });
    if (!outputContext) throw new Error("Canvas is not available.");
    const fillRegionMap = new Uint16Array(width * height);
    const outlineMask = new Uint8Array(width * height);
    const regions = [];
    let nextRegionId = 0;
    let maxLineThickness = 0;
    for (const layer of layers){
        const fitted = layer.canvas.width === width && layer.canvas.height === height ? layer.canvas : (()=>{
            const canvas = createProcessingCanvas(width, height);
            const context = getProcessingContext(canvas, {
                willReadFrequently: true
            });
            if (!context) throw new Error("Canvas is not available.");
            context.drawImage(layer.canvas, 0, 0, width, height);
            return canvas;
        })();
        const fittedContext = getProcessingContext(fitted, {
            willReadFrequently: true
        });
        if (!fittedContext) throw new Error("Canvas is not available.");
        const sourceData = fittedContext.getImageData(0, 0, width, height);
        const { enclosedFillMask, outlineMask: layerOutlineMask, sourceFillMask } = buildArtworkMasks(sourceData, layer.settings);
        const local = labelFillRegions([
            {
                mask: sourceFillMask,
                kind: "source"
            },
            {
                mask: enclosedFillMask,
                kind: "enclosed"
            }
        ], width, height, settings);
        const regionNumberMap = new Map();
        for (const region of local.regions){
            if (nextRegionId >= 65535) break;
            nextRegionId += 1;
            const globalId = String(nextRegionId);
            regionNumberMap.set(Number(region.id), nextRegionId);
            regions.push({
                ...region,
                id: globalId,
                color: fillColorForRegion(settings, globalId, region.kind)
            });
        }
        for(let pixel = 0; pixel < local.fillRegionMap.length; pixel += 1){
            const localRegionNumber = local.fillRegionMap[pixel];
            if (!localRegionNumber) continue;
            const globalRegionNumber = regionNumberMap.get(localRegionNumber);
            if (globalRegionNumber) fillRegionMap[pixel] = globalRegionNumber;
        }
        for(let pixel = 0; pixel < layerOutlineMask.length; pixel += 1){
            if (layerOutlineMask[pixel]) outlineMask[pixel] = 1;
        }
        maxLineThickness = Math.max(maxLineThickness, (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$graph$2d$paper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clampImageLineThickness"])(layer.settings.imageLineThickness));
    }
    const visibleCounts = new Map();
    for(let pixel = 0; pixel < fillRegionMap.length; pixel += 1){
        const regionNumber = fillRegionMap[pixel];
        if (regionNumber) visibleCounts.set(String(regionNumber), (visibleCounts.get(String(regionNumber)) ?? 0) + 1);
    }
    const visibleRegions = regions.map((region)=>({
            ...region,
            cellCount: visibleCounts.get(region.id) ?? 0,
            color: fillColorForRegion(settings, region.id, region.kind)
        })).filter((region)=>region.cellCount > 0);
    outputContext.fillStyle = settings.backgroundColor || "#ffffff";
    outputContext.fillRect(0, 0, output.width, output.height);
    if (settings.gridLineLayer === "back") drawGraphPaperGrid(output, settings);
    drawFillRegions(outputContext, fillRegionMap, visibleRegions, output.width, output.height, settings, 0.8);
    drawMaskLayer(outputContext, outlineMask, output.width, output.height, settings.outlineColor || settings.lineColor, 255, 0.12 * maxLineThickness);
    if (settings.gridLineLayer !== "back") drawGraphPaperGrid(output, settings);
    drawManualGraphArtwork(output, settings);
    drawGridNumbers(output, settings);
    const outlineHex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$color$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rgbToHex"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$color$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hexToRgb"])(settings.outlineColor || settings.lineColor));
    const outlineCount = outlineMask.reduce((sum, value)=>sum + value, 0);
    const fillCountsByColor = new Map();
    const visibleRegionById = new Map(visibleRegions.map((region)=>[
            region.id,
            region
        ]));
    for (const [regionId, cellCount] of visibleCounts){
        const region = visibleRegionById.get(regionId);
        if (!region) continue;
        const color = fillColorForRegion(settings, region.id, region.kind);
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$graph$2d$paper$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isTransparentFillColor"])(color)) continue;
        const hex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$color$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rgbToHex"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$color$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hexToRgb"])(color));
        fillCountsByColor.set(hex, (fillCountsByColor.get(hex) ?? 0) + cellCount);
    }
    return {
        canvas: output,
        palette: [
            {
                name: "Outline",
                hex: outlineHex,
                locked: true,
                cellCount: outlineCount,
                sortOrder: 0
            },
            ...Array.from(fillCountsByColor.entries()).map(([hex, cellCount], index)=>({
                    name: index === 0 ? "Fill" : `Fill ${index + 1}`,
                    hex,
                    locked: true,
                    cellCount,
                    sortOrder: index + 1
                }))
        ],
        fillRegions: visibleRegions,
        fillRegionMap
    };
}
function pixelateLayeredImages(layers, settings) {
    return pixelateLayeredCanvases(layers, settings);
}
function generateGridOverlay(canvas, settings) {
    drawGraphPaperGrid(canvas, settings);
}
async function pixelateImageWithWorker(sourceCanvas, settings, _palette, options = {}) {
    return pixelateImage(sourceCanvas, settings, options);
}
function supportsCanvasWorker() {
    return ("TURBOPACK compile-time value", "object") !== "undefined" && typeof Worker !== "undefined" && typeof OffscreenCanvas !== "undefined" && typeof createImageBitmap === "function";
}
function processingAbortError() {
    const error = new Error("Image processing was cancelled.");
    error.name = "AbortError";
    return error;
}
async function pixelateLayeredImagesInWorker(layers, settings, signal) {
    if (signal?.aborted) throw processingAbortError();
    const bitmaps = await Promise.all(layers.map((layer)=>createImageBitmap(layer.canvas)));
    if (signal?.aborted) {
        bitmaps.forEach((bitmap)=>bitmap.close());
        throw processingAbortError();
    }
    const worker = __turbopack_context__.r("[project]/src/lib/canvas/processor.worker.ts [app-client] (ecmascript, worker loader)")(Worker, {
        type: "module"
    });
    const workerLayers = layers.map((layer, index)=>({
            bitmap: bitmaps[index],
            settings: layer.settings
        }));
    return new Promise((resolve, reject)=>{
        let settled = false;
        let postedToWorker = false;
        function cleanup() {
            signal?.removeEventListener("abort", abort);
            worker.terminate();
        }
        function abort() {
            if (settled) return;
            settled = true;
            if (!postedToWorker) bitmaps.forEach((bitmap)=>bitmap.close());
            cleanup();
            reject(processingAbortError());
        }
        worker.onmessage = (event)=>{
            if (settled) return;
            settled = true;
            cleanup();
            const data = event.data;
            if (!data.ok || !data.bitmap || !data.fillRegionMap || !data.palette || !data.fillRegions) {
                reject(new Error(data.error || "Unable to process image."));
                return;
            }
            const canvas = document.createElement("canvas");
            canvas.width = data.width ?? data.bitmap.width;
            canvas.height = data.height ?? data.bitmap.height;
            const context = canvas.getContext("2d", {
                willReadFrequently: true
            });
            if (!context) {
                data.bitmap.close();
                reject(new Error("Canvas is not available."));
                return;
            }
            context.drawImage(data.bitmap, 0, 0);
            data.bitmap.close();
            resolve({
                canvas,
                palette: data.palette,
                fillRegions: data.fillRegions,
                fillRegionMap: data.fillRegionMap
            });
        };
        worker.onerror = (event)=>{
            if (settled) return;
            settled = true;
            cleanup();
            reject(new Error(event.message || "Unable to process image."));
        };
        signal?.addEventListener("abort", abort, {
            once: true
        });
        postedToWorker = true;
        worker.postMessage({
            layers: workerLayers,
            settings
        }, bitmaps);
    });
}
async function pixelateLayeredImagesWithWorker(layers, settings, options = {}) {
    if (!supportsCanvasWorker()) return pixelateLayeredImages(layers, settings);
    try {
        return await pixelateLayeredImagesInWorker(layers, settings, options.signal);
    } catch (error) {
        if (options.signal?.aborted || error instanceof Error && error.name === "AbortError") throw error;
        return pixelateLayeredImages(layers, settings);
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/canvas/processor.worker.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$processor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/canvas/processor.ts [app-client] (ecmascript)");
;
const workerContext = self;
workerContext.onmessage = (event)=>{
    const bitmaps = event.data.layers.map((layer)=>layer.bitmap);
    try {
        const layers = event.data.layers.map((layer)=>{
            const canvas = new OffscreenCanvas(layer.bitmap.width, layer.bitmap.height);
            const context = canvas.getContext("2d", {
                willReadFrequently: true
            });
            if (!context) throw new Error("Canvas is not available.");
            context.drawImage(layer.bitmap, 0, 0);
            return {
                canvas,
                settings: layer.settings
            };
        });
        bitmaps.forEach((bitmap)=>bitmap.close());
        const result = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$canvas$2f$processor$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pixelateLayeredCanvases"])(layers, event.data.settings);
        const output = result.canvas;
        const bitmap = output.transferToImageBitmap();
        const response = {
            ok: true,
            bitmap,
            width: output.width,
            height: output.height,
            palette: result.palette,
            fillRegions: result.fillRegions,
            fillRegionMap: result.fillRegionMap
        };
        workerContext.postMessage(response, [
            bitmap,
            result.fillRegionMap.buffer
        ]);
    } catch (error) {
        bitmaps.forEach((bitmap)=>bitmap.close());
        const response = {
            ok: false,
            error: error instanceof Error ? error.message : "Unable to process image."
        };
        workerContext.postMessage(response);
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/node_modules/pdfjs-dist/build/pdf.worker.mjs (static in ecmascript, tag client)", ((__turbopack_context__) => {

__turbopack_context__.q("/_next/static/media/pdf.worker.25ho45-5ac_dr.mjs");}),
]);

//# sourceMappingURL=_0fge0po._.js.map