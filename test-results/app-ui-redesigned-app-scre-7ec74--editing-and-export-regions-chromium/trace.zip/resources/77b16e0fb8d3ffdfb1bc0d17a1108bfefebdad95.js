(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/node_modules_pdfjs-dist_build_pdf_mjs_0urn6q8._.js","static/chunks/_0fge0po._.js"],
    source: "entry"
});
